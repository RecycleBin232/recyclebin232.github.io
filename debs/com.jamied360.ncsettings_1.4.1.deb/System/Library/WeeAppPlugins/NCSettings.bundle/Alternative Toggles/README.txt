Included here are blue/grey colour scheme toggles, and the WeeAppBackground without the subtle shadow.

Personally i don't like the blue colour scheme, i don't think it fits with the colours of the Notification Centre.

But by all means, you can use them if you like them. Steps as follows:

- Backup the original 'Toggles' folder in the bundle. Then replace it with this 'Toggles' folder.
- Same for the WeeAppBackground.